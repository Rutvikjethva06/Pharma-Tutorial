document.addEventListener('DOMContentLoaded', function () {
  const loginForm = document.getElementById('loginForm');
  if (loginForm) {
    loginForm.addEventListener('submit', function (e) {
      e.preventDefault();
      const username = document.getElementById('username').value;
      const password = document.getElementById('password').value;
      const loginMessage = document.getElementById('loginMessage');
      if (username === "student" && password === "1234") {
        loginMessage.textContent = "Login successful! Redirecting...";
        loginMessage.style.color = "green";
        setTimeout(() => { window.location.href = "dashboard.html"; }, 1500);
      } else {
        loginMessage.textContent = "Invalid username or password!";
        loginMessage.style.color = "red";
      }
    });
  }
});